# Selenium-POM-TestNG-Maven
This is sample of widely used POM framework in selenium using Java as scripting language. Maven is used for dependency management and continuous development. TestNG is used to maintain test cases


Downlaod project in your local machine and Import Project as exisitng maven project.
After imporitng, use 'mvn clean' command
Use 'mvn test' to execute test cases.
